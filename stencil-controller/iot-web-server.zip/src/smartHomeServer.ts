//tcp local communication
import * as dgram from 'dgram'
import { WebSocketServer } from './smartHomeWebServer'

export class SmartHomeServer {
    private socket: dgram.Socket
    private address: string
    private port: number
    private webServer: WebSocketServer

    public constructor(address: string = 'http://smartlightsnem.us-east-2.elasticbeanstalk.com/', port: number = 8888) {
    this.socket = dgram.createSocket('udp4')
    this.address = address
    this.port = port
    this.webServer = new WebSocketServer()
}

    public command<TRequest>(request: TRequest): Promise < any > {
    console.log("pinged", request)
    
    return new Promise((resolve, reject) => {
        const message = JSON.stringify(request)
        this.webServer.sendMessage(message)
        this.socket.send(message, this.port, this.address, (err) => {
            if (err) {
                reject()
                return
            }
        })

        const error = (err: Error) => {
            this.socket.removeListener('error', error)
            reject(err)
        }

        const receive = (buffer: Buffer) => {
            this.socket.removeListener('error', error)
            this.socket.removeListener('message', receive)
            const data = JSON.parse(buffer.toString())
            resolve(data)
        }

        this.socket.once('error', error)
        this.socket.once('message', receive)
    })
}
}