import { Message, User } from './webServerModels'
import * as express from 'express'
import * as http from 'http'
import * as WebSocket from 'ws'

export class WebSocketServer {
    public static readonly PORT: number = 80
    private app: express.Application | null = null
    private webSocketServer: WebSocket.Server | null = null

    private clients: string[] = []

    constructor() {
        this.createApp()
        this.createServer()
        this.listen()
    }

    private createApp(): void {
        this.app = express()
    }

    private createServer(): void {
        const server = http.createServer(this.app!)
        this.webSocketServer = new WebSocket.Server({ server })
        server.listen(process.env.PORT || WebSocketServer.PORT, () => {
            console.log(`Server started on port ${WebSocketServer.PORT}`);
        });
        console.log("server created")
    }

    public sendMessage(message: string): void {
        var m: Message = {
            from: new User('Server'),
            content: message
        }
    }

    private listen(): void {
        this.webSocketServer!.on('connection', (ws: WebSocket) => {
            console.log("device connected")
            ws.send('welcome to the network')
            //connection is up, let's add a simple simple event
            ws.on('message', ((message: string) => {

                //log the received message and send it back to the client
                console.log('received: %s', message)
                ws.send(`Hello, you sent -> ${message}`)
            }))
        })
    }
}